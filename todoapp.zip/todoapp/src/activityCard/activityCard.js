import React from 'react'
import style from './activityCard.module.css'

const ActivityCard = ({title='card title',secondHalf=[],firstHlafHeader=[],cardFooter}) => {
  console.log(secondHalf)
  return (
    <div className={secondHalf.length>0?style['large-card-container']:style['card-container']}>
        <header>
         <h5>{title}</h5>
        </header>
        <footer>
           <div className={style['first-half']}>
            <div>
            {
              firstHlafHeader.map((el,i) => {
                return <React.Fragment key={`${el?.title}`}>
             <div className={style['card-details']}>
              <div >
                <div>{el?.title}</div>
                <div className={style['normal-text']}>
                  {el?.percentage}
                </div>
              </div>
              <div className={style['card-month-cotainer']}>
                <div className={style['large-text']}>{el?.value}</div>
                <div >{el?.valueIndicator}</div>

              </div>
             </div>
                </React.Fragment>
              })
            }
            </div>
            <div className={style['first-half-footer']}>
           <div className={style['review-container']}>
            <div>{cardFooter.title}</div>
            <div>🔔</div>
           </div>
           <div  className={style['review-details']}>
           {
            cardFooter.list.map((el,i) =>{
              return <React.Fragment key={`${el.title}${i}`}>
                <div >
                  <div className={style['review-text']}>
                    {el.value}
                  </div>
                  <div>
                    {el.text}
                  </div>
                </div>


              </React.Fragment>
            })
           }
           </div>
            </div>
           </div>
           {
            secondHalf.length>0&& <div className={style['second-half']}>
               {
              secondHalf.map((el,i) => {
                return <React.Fragment key={`${el?.title}`}>
             <div className={style['card-second-details']}>
             <div className={style['card-secodHalf-title']}>
             <div >
                <div>{el?.title}</div>
                <div className={style['normal-text']}>
                  {el?.percentage}
                </div>
              </div>
              <div className={style['second-half-value']}>
                <div className={style['large-text']}>{el?.value}</div>
                <div >{el?.valueIndicator}</div>

              </div>
             </div>
              <div className={style['secondHalf-details']}>
              {
                el?.footer?.map((footerList,footerIndex) => {
                  return  <div className={style['footer-button']} key={`${footerList.value}${footerIndex}`}>
                  <span>{footerList.value}</span>
                  <span>{footerList.tenure}</span>
                 </div>
                })
              }

              </div>
             </div>
                </React.Fragment>
              })
            }
            </div>
           }
        </footer>
    </div>
  )
}

export default ActivityCard