import React from 'react'
import style from './activityCard.module.css'

const ActivityCard = ({title='card title',secondHalf=[]}) => {
  console.log(secondHalf)
  return (
    <div className={style['card-container']}>
        <header>
         <h5>{title}</h5>
        </header>
        <footer>
           <div className={style['first-half']}></div>
           {
            secondHalf.length>0&& <div className={style['second-half']}></div>
           }
        </footer>
    </div>
  )
}

export default ActivityCard