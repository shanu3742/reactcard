import React, { useState } from "react";
import "./App.css"; // Import the SCSS file
import ActivityCard from "./activityCard/activityCard";

const App = () => {
  
let response=[
  {
    title:'User Activity',
    firstHlaf:{
      header:[
        
          
            {
              title:'active User',
              value:9991,
              percentage:'10%',
              valueIndicator:''
            },
            {
              title:'Repeat visitors',
              value:6991,
              percentage:'10%',
              valueIndicator:'Month'
    
            },
      ]
        
      },
      secondHalf:[
       
        {
          title:'Avg Seed tenure',
          value:24,
          percentage:'10%',
          valueIndicator:'Months',
          footer:[
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            }
          ]
        },
        {
          title:'Avg Streaks',
          value:24,
          percentage:'10%',
          valueIndicator:'Months',
          footer:[
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            }
          ]
        },
        
       
    ],
      footer:{
         title:'Need to reviews',
         list:[
          {
            text:'Expiring',
            value:24
          },
          {
            text:'Expiring',
            value:14
          },
          {
            text:'Expiring',
            value:2
          }

         ]
      }
    },


    {
      title:'User Activity3',
      firstHlaf:{
        header:[
          
            
              {
                title:'active User',
                value:9991,
                percentage:'10%',
                valueIndicator:''
              },
              {
                title:'Repeat visitors',
                value:6991,
                percentage:'10%',
                valueIndicator:'Month'
      
              },
        ]
          
        },
        secondHalf:[  
      ],
        footer:{
           title:'Need to reviews',
           list:[
            {
              text:'Expiring',
              value:24
            },
            {
              text:'Expiring',
              value:14
            },
            {
              text:'Expiring',
              value:2
            }
  
           ]
        }
      },
      {
        title:'User Activity2',
        firstHlaf:{
          header:[
            
              
                {
                  title:'active User',
                  value:9991,
                  percentage:'10%',
                  valueIndicator:''
                },
                {
                  title:'Repeat visitors',
                  value:6991,
                  percentage:'10%',
                  valueIndicator:'Month'
        
                },
          ]
            
          },
          secondHalf:[  
        ],
          footer:{
             title:'Need to reviews',
             list:[
              {
                text:'Expiring',
                value:24
              },
              {
                text:'Expiring',
                value:14
              },
              {
                text:'Expiring',
                value:2
              }
    
             ]
          }

        },
        {
          title:'User Activity',
          firstHlaf:{
            header:[
              
                
                  {
                    title:'active User',
                    value:9991,
                    percentage:'10%',
                    valueIndicator:''
                  },
                  {
                    title:'Repeat visitors',
                    value:6991,
                    percentage:'10%',
                    valueIndicator:'Month'
          
                  },
            ]
              
            },
            secondHalf:[
             
              {
                title:'Avg Seed tenure',
                value:24,
                percentage:'10%',
                valueIndicator:'Months',
                footer:[
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  }
                ]
              },
              {
                title:'Avg Streaks',
                value:24,
                percentage:'10%',
                valueIndicator:'Months',
                footer:[
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  },
                  {
                    value:981,
                    tenure:'0-6m'
                  }
                ]
              },
              
             
          ],
            footer:{
               title:'Need to reviews',
               list:[
                {
                  text:'Expiring',
                  value:24
                },
                {
                  text:'Expiring',
                  value:14
                },
                {
                  text:'Expiring',
                  value:2
                }
      
               ]
            }
          },
          {
            title:'User Activity',
            firstHlaf:{
              header:[
                
                  
                    {
                      title:'active User',
                      value:9991,
                      percentage:'10%',
                      valueIndicator:''
                    },
                    {
                      title:'Repeat visitors',
                      value:6991,
                      percentage:'10%',
                      valueIndicator:'Month'
            
                    },
              ]
                
              },
              secondHalf:[
               
                {
                  title:'Avg Seed tenure',
                  value:24,
                  percentage:'10%',
                  valueIndicator:'Months',
                  footer:[
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    }
                  ]
                },
                {
                  title:'Avg Streaks',
                  value:24,
                  percentage:'10%',
                  valueIndicator:'Months',
                  footer:[
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    },
                    {
                      value:981,
                      tenure:'0-6m'
                    }
                  ]
                },
                
               
            ],
              footer:{
                 title:'Need to reviews',
                 list:[
                  {
                    text:'Expiring',
                    value:24
                  },
                  {
                    text:'Expiring',
                    value:14
                  },
                  {
                    text:'Expiring',
                    value:2
                  }
        
                 ]
              }
            },
              {
    title:'User Activity',
    firstHlaf:{
      header:[
        
          
            {
              title:'active User',
              value:9991,
              percentage:'10%',
              valueIndicator:''
            },
            {
              title:'Repeat visitors',
              value:6991,
              percentage:'10%',
              valueIndicator:'Month'
    
            },
      ]
        
      },
      secondHalf:[
       
        {
          title:'Avg Seed tenure',
          value:24,
          percentage:'10%',
          valueIndicator:'Months',
          footer:[
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            }
          ]
        },
        {
          title:'Avg Streaks',
          value:24,
          percentage:'10%',
          valueIndicator:'Months',
          footer:[
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            },
            {
              value:981,
              tenure:'0-6m'
            }
          ]
        },
        
       
    ],
      footer:{
         title:'Need to reviews',
         list:[
          {
            text:'Expiring',
            value:24
          },
          {
            text:'Expiring',
            value:14
          },
          {
            text:'Expiring',
            value:2
          }

         ]
      }
    },
    {
      title:'User Activity',
      firstHlaf:{
        header:[
          
            
              {
                title:'active User',
                value:9991,
                percentage:'10%',
                valueIndicator:''
              },
              {
                title:'Repeat visitors',
                value:6991,
                percentage:'10%',
                valueIndicator:'Month'
      
              },
        ]
          
        },
        secondHalf:[
         
          {
            title:'Avg Seed tenure',
            value:24,
            percentage:'10%',
            valueIndicator:'Months',
            footer:[
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              }
            ]
          },
          {
            title:'Avg Streaks',
            value:24,
            percentage:'10%',
            valueIndicator:'Months',
            footer:[
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              },
              {
                value:981,
                tenure:'0-6m'
              }
            ]
          },
          
         
      ],
        footer:{
           title:'Need to reviews',
           list:[
            {
              text:'Expiring',
              value:24
            },
            {
              text:'Expiring',
              value:14
            },
            {
              text:'Expiring',
              value:2
            }
  
           ]
        }
      },
   


]
  return (
    <div className='app'>
    <div className="card-list">
    {
      response.map((el,i) => {
      return  <React.Fragment key={i}>
         <ActivityCard title={el?.title} secondHalf={el.secondHalf} firstHlafHeader={el.firstHlaf.header} cardFooter={el.footer}/>
        </React.Fragment>
      })
    }
    </div>
    </div>
  );
};

export default App;